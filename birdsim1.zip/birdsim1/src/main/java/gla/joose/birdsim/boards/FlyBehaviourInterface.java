package gla.joose.birdsim.boards;

public interface FlyBehaviourInterface {
	
	
	public void fly();
	

}


